
const express = require('express');
const router = express.Router();
const pool = require('../db');

router.get('/total-sales', async (req, res) => {
  const { start, end } = req.query;
  try {
    const result = await pool.query('SELECT get_total_sales($1, $2) AS total_sales', [start, end]);
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;
