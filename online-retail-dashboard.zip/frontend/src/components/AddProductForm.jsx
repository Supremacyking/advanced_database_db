
import React from 'react';
export default function AddProductForm() {
  return <div>Add Product Form</div>;
}
