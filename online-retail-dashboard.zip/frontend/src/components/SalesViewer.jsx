
import React, { useState } from 'react';
import axios from 'axios';

export default function SalesViewer() {
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [totalSales, setTotalSales] = useState(null);

  const fetchTotalSales = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/sales/total-sales', {
        params: { start, end }
      });
      setTotalSales(response.data.total_sales);
    } catch (error) {
      console.error('Error fetching sales:', error);
    }
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Total Sales Calculator</h2>
      <div className="flex gap-4 mb-4">
        <input type="date" value={start} onChange={(e) => setStart(e.target.value)} className="p-2 border" />
        <input type="date" value={end} onChange={(e) => setEnd(e.target.value)} className="p-2 border" />
        <button onClick={fetchTotalSales} className="bg-blue-600 text-white px-4 py-2 rounded">Get Sales</button>
      </div>
      {totalSales !== null && <p className="text-lg font-medium">Total Sales: ${Number(totalSales).toFixed(2)}</p>}
    </div>
  );
}
