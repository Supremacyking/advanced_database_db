
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ProductList from './components/ProductList';
import AddProductForm from './components/AddProductForm';
import SalesViewer from './components/SalesViewer';

export default function App() {
  return (
    <Router>
      <div className="p-6 bg-gray-100 min-h-screen">
        <h1 className="text-3xl font-bold mb-6">Online Retail II Dashboard</h1>
        <Routes>
          <Route path="/" element={<ProductList />} />
          <Route path="/add" element={<AddProductForm />} />
          <Route path="/sales" element={<SalesViewer />} />
        </Routes>
      </div>
    </Router>
  );
}
